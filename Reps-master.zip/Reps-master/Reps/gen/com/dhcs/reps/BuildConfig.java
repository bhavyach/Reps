/** Automatically generated file. DO NOT MODIFY */
package com.dhcs.reps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}